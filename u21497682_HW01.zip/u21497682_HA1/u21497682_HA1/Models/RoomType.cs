﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace u21497682_HA1.Models
{
    public class RoomType
    {
        //public int RoomTypeId { get; set; }
        //public int HotelId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Features { get; set; } 
    }
}