﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace u21497682_HA1.Models
{
    public class IDType
    {
        public string TypeName { get; set; }
    }
}